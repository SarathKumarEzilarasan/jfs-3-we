package demo;

import java.util.LinkedList;
import java.util.Queue;

class TNode {
    int data;
    TNode left, right;

    TNode(int data) {
        this.data = data;
    }
}

public class BinaryTree {
    TNode root;

    public void preOrder(TNode node) {
        if (node == null) {
            return;
        }
        System.out.println(node.data);
        preOrder(node.left);
        preOrder(node.right);
    }

    public void inOrder(TNode node) {
        if (node == null) {
            return;
        }
        inOrder(node.left);
        System.out.println(node.data);
        inOrder(node.right);
    }

    public void postOrder(TNode node) {
        if (node == null) {
            return;
        }
        postOrder(node.right);
        System.out.println(node.data);
        postOrder(node.left);
    }

    public int height(TNode node) {
        if (node == null) {
            return 0;
        }
        return 1 + Math.max(height(node.left), height(node.right));
    }

    public void levelOrder() {
        if (root == null) {
            return;
        }

        Queue<TNode> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            TNode tempNode = queue.poll();
            System.out.println(tempNode.data);
            if (tempNode.left != null) {
                queue.add(tempNode.left);
            }
            if (tempNode.right != null) {
                queue.add(tempNode.right);
            }
        }
    }

    public boolean isChildSumProperty(TNode node) {
        if (node == null || (node.left == null && node.right == null)) {
            return true;
        }
        int leftData = (node.left != null) ? node.left.data : 0;
        int rightData = (node.right != null) ? node.right.data : 0;

        if (node.data == leftData + rightData) {
            return isChildSumProperty(node.left) && isChildSumProperty(node.right);
        }
        return false;
    }

    public static void main(String[] args) {
        BinaryTree tree = new BinaryTree();
        tree.root = new TNode(12);
        tree.root.left = new TNode(8);
        tree.root.right = new TNode(14);
        tree.root.left.left = new TNode(4);
        tree.root.left.right = new TNode(4);

        System.out.println(tree.isChildSumProperty(tree.root));
    }
}
