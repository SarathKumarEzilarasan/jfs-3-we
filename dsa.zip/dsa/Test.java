package demo;

public class Test {
    public static void main(String[] args) {
        String s = "wwwaaccccdd";
        char previousCh = s.charAt(0);
        int counter = 1;
        String op = "";

        for (int i = 1; i < s.length(); i++) {
            char currentCh = s.charAt(i);
            if (currentCh == previousCh) {
                counter++;
            } else {
                op = op + previousCh + counter;
                counter = 1;
                previousCh = currentCh;
            }
        }
        op = op + s.charAt(s.length() - 1) + counter;
        System.out.println(op);
    }
}
