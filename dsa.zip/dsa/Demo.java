package demo;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class Demo {
    // complexity analysis
    //              -> time complexity -> o()
    //              -> space complexity

    public static void main(String[] args) {
        // wwwaaccccdww -> w5a2c4d1
        //              -> w3a3c4d1w2

        String s = "wwwaaccccd";
        Map<Character, Integer> map = new LinkedHashMap<>();

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (map.containsKey(ch)) {
                int oldValue = map.get(ch);
                map.put(ch, oldValue + 1);
            } else {
                map.put(ch, 1);
            }
        }

        System.out.println(map);

        // time  -> o(n)
        // space -> o(n)



    }


}
