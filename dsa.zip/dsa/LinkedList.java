package demo;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        next = null;
    }
}


public class LinkedList {
    Node head;

    public void setHead(Node head){
        this.head = head;
    }

    public void append(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            head = newNode;
            return;
        }
        Node last = head;
        while (last.next != null) {
            last = last.next;
        }
        last.next = newNode;
    }

    public void delete(int data) {
        Node temp = head, prev = null;
        if (temp != null && temp.data == data) {
            head = temp.next;
            return;
        }
        while (temp != null && temp.data != data) {
            prev = temp;
            temp = temp.next;
        }
        if (temp == null) {
            return;
        }
        prev.next = temp.next;
    }

    public void printList() {
        Node currentNode = head;
        while (currentNode != null) {
            System.out.print(currentNode.data);
            currentNode = currentNode.next;
        }
        System.out.println();
    }

    public void reverse() {
        Node prev = null, next = null;
        Node current = head;

        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }

        head = prev;
    }

    // fast = fast.next.next;
    public int detectAndCountLoop() {
        Node slow = head, fast = head;

        while (slow != null && fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;

            if (slow == fast) {
                return getLoopSize(slow);
            }
        }
        return 0;
    }

    public int getLoopSize(Node node) {
        int size = 1;
        Node current = node;

        while (current.next != node) {
            current = current.next;
            size++;
        }
        return size;
    }

    public static void main(String[] args) {
        LinkedList list = new LinkedList();
        Node node = new Node(1);
        Node node1 = new Node(2);
        Node node2 = new Node(3);
        Node node3 = new Node(4);

        node.next = node1;
        node1.next = node2;
        node2.next = node3;
//        node3.next = node1;

        list.setHead(node);
        System.out.println(list.detectAndCountLoop());

    }

}

// 100            1 -> 0 -> 9            1 <- 0 <- 9
// 200            2 -> 0 -> 1            2 <- 0 <- 1

//                3 -> 1 -> 0







